package sistemasuniversitarios;

import banco.CuentaCorriente;
import java.time.LocalDate;
import java.time.Period;

public class Trabajador extends Persona {

    private CuentaCorriente[] cuentas;
    private static final int MAX_CUENTAS = 3;
    private int totalCuentas;

    private String identificador;
    private LocalDate fechaIngreso;
    private double salario;
    private String puesto;

    public Trabajador(LocalDate fechaIngreso,
                      double salario,
                      String identificador,
                      String puesto,
                      String nombre,
                      LocalDate fechaNacimiento,
                      String direccion) {

        super(nombre, fechaNacimiento, direccion);

        this.identificador = identificador;
        this.fechaIngreso = fechaIngreso;
        this.puesto = puesto;
        this.salario = salario;

        cuentas = new CuentaCorriente[MAX_CUENTAS];
    }

    public Trabajador() {
        super();
        this.identificador = "";
        this.fechaIngreso = LocalDate.now();
        this.salario = 0;
        this.puesto = "";

        cuentas = new CuentaCorriente[MAX_CUENTAS];
    }

    public CuentaCorriente[] getCuentas() {
        return cuentas;
    }

    public int getTotalCuentas() {
        return totalCuentas;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public boolean agregarCuenta(CuentaCorriente cuenta) {
        if (totalCuentas < MAX_CUENTAS) {
            cuentas[totalCuentas++] = cuenta;
            return true;
        }
        return false;
    }

public void mostrarCuentas() {
    if (totalCuentas == 0) {
        System.out.println("No tiene cuentas registradas.");
        return;
    }

    for (int i = 0; i < totalCuentas; i++) {
        System.out.println(cuentas[i]);
    }
}



    public CuentaCorriente buscarCuenta(String numeroCuenta) {
        for (int i = 0; i < totalCuentas; i++) {
            if (cuentas[i] != null &&
                cuentas[i].getNumeroCuenta().equals(numeroCuenta)) {
                return cuentas[i];
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return super.toString() +
                "\nIdentificador: " + identificador +
                "\nFecha ingreso: " + fechaIngreso +
                "\nSalario: " + salario +
                "\nPuesto: " + puesto +
                "\nTotal cuentas: " + totalCuentas;
    }
}
