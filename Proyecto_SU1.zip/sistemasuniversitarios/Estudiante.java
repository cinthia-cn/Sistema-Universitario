package sistemasuniversitarios;

import banco.CuentaAhorro;
import java.time.LocalDate;

public class Estudiante extends Persona {

    private static final int MAX_CUENTAS = 3;
    private CuentaAhorro[] cuentas;
    private int totalCuentas;

    private String matricula;
    private double promedio;
    private LocalDate fechaIngreso;

    public Estudiante(String matricula,
                      double promedio,
                      LocalDate fechaIngreso,
                      String nombre,
                      LocalDate fechaNacimiento,
                      String direccion) {

        super(nombre, fechaNacimiento, direccion);

        this.matricula = matricula;
        this.promedio = promedio;
        this.fechaIngreso = fechaIngreso;

        cuentas = new CuentaAhorro[MAX_CUENTAS];
    }

    public Estudiante() {
        super();
        this.matricula = "";
        this.promedio = 0;
        this.fechaIngreso = LocalDate.now();

        cuentas = new CuentaAhorro[MAX_CUENTAS];
    }

    public String getMatricula() {
        return matricula;
    }

    public double getPromedio() {
        return promedio;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public CuentaAhorro[] getCuentas() {
        return cuentas;
    }

    public int getTotalCuentas() {
        return totalCuentas;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

public void mostrarCuentas() {
    if (totalCuentas == 0) {
        System.out.println("No tiene cuentas registradas.");
        return;
    }

    for (int i = 0; i < totalCuentas; i++) {
        System.out.println(cuentas[i]);
    }
}



    public boolean agregarCuenta(CuentaAhorro cuenta) {
        if (totalCuentas < MAX_CUENTAS) {
            cuentas[totalCuentas++] = cuenta;
            return true;
        }
        return false;
    }

    public CuentaAhorro buscarCuenta(String numeroCuenta) {
        for (int i = 0; i < totalCuentas; i++) {
            if (cuentas[i] != null &&
                cuentas[i].getNumeroCuenta().equals(numeroCuenta)) {
                return cuentas[i];
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return super.toString() +
                "\nMatricula: " + matricula +
                "\nPromedio: " + promedio +
                "\nFecha ingreso: " + fechaIngreso;
    }
}
