package sistemasuniversitarios;

import java.time.LocalDate;
import java.time.Period;

public class Persona {

    private String nombre;
    private LocalDate fechaNacimiento;
    private String direccion;

    public Persona(String nombre, LocalDate fechaNacimiento, String direccion) {
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
    }

    public Persona() {
        this.nombre = "";
        this.fechaNacimiento = LocalDate.now();
        this.direccion = "";
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int obtenerEdad() {
        return Period.between(fechaNacimiento, LocalDate.now()).getYears();
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre +
                "\nEdad: " + obtenerEdad() +
                "\nDireccion: " + direccion;
    }
}
